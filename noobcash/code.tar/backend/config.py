# ----- Global Settings -----

CAPACITY = 10
DIFFICULTY = 4
IS_COORDINATOR = None     
NODE_CAPACITY = 5
START = 'no'
